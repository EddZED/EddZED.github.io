
tippy('.tippy', {
	content: "I'm a Tippy tooltip!",
});