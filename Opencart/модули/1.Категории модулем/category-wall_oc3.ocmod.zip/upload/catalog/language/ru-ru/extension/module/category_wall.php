<?php
// Heading
$_['heading_title'] = 'Категории';