<?php
class ControllerExtensionModuleAdCategory extends Controller {
	private $error = array();

	public function index() {
		$data['adc_version'] = '1.1 (Opencart 3.0.x)';

		$this->load->language('extension/module/ad_category');
		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_ad_category', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['install_db'])) {
			$data['install_db'] = $this->session->data['install_db'];
			unset($this->session->data['install_db']);
		} else {
			$data['install_db'] = '';
		}
		
		if (isset($this->session->data['uninstall_db'])) {
			$data['uninstall_db'] = $this->session->data['uninstall_db'];
			unset($this->session->data['uninstall_db']);
		} else {
			$data['uninstall_db'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		$data['install_read_more_1'] = $this->url->link('extension/module/ad_category/installReadMore1', 'user_token=' . $this->session->data['user_token'], true);
		$data['install_read_more_2'] = $this->url->link('extension/module/ad_category/installReadMore2', 'user_token=' . $this->session->data['user_token'], true);
		$data['install_height_box_1'] = $this->url->link('extension/module/ad_category/installHeightBox1', 'user_token=' . $this->session->data['user_token'], true);
		$data['install_height_box_2'] = $this->url->link('extension/module/ad_category/installHeightBox2', 'user_token=' . $this->session->data['user_token'], true);
		$data['install_hide_box_1'] = $this->url->link('extension/module/ad_category/installHideBox1', 'user_token=' . $this->session->data['user_token'], true);
		$data['install_hide_box_2'] = $this->url->link('extension/module/ad_category/installHideBox2', 'user_token=' . $this->session->data['user_token'], true);
		$data['install_bottom_title'] = $this->url->link('extension/module/ad_category/installBottomTitle', 'user_token=' . $this->session->data['user_token'], true);
		$data['install_bottom_description'] = $this->url->link('extension/module/ad_category/installBottomDescription', 'user_token=' . $this->session->data['user_token'], true);

		$data['uninstall_read_more_1'] = $this->url->link('extension/module/ad_category/uninstallReadMore1', 'user_token=' . $this->session->data['user_token'], true);
		$data['uninstall_read_more_2'] = $this->url->link('extension/module/ad_category/uninstallReadMore2', 'user_token=' . $this->session->data['user_token'], true);
		$data['uninstall_height_box_1'] = $this->url->link('extension/module/ad_category/uninstallHeightBox1', 'user_token=' . $this->session->data['user_token'], true);
		$data['uninstall_height_box_2'] = $this->url->link('extension/module/ad_category/uninstallHeightBox2', 'user_token=' . $this->session->data['user_token'], true);
		$data['uninstall_hide_box_1'] = $this->url->link('extension/module/ad_category/uninstallHideBox1', 'user_token=' . $this->session->data['user_token'], true);
		$data['uninstall_hide_box_2'] = $this->url->link('extension/module/ad_category/uninstallHideBox2', 'user_token=' . $this->session->data['user_token'], true);
		$data['uninstall_bottom_title'] = $this->url->link('extension/module/ad_category/uninstallBottomTitle', 'user_token=' . $this->session->data['user_token'], true);
		$data['uninstall_bottom_description'] = $this->url->link('extension/module/ad_category/uninstallBottomDescription', 'user_token=' . $this->session->data['user_token'], true);

		$result_read_more_1 = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'read_more_1'");
		if ($result_read_more_1->num_rows == 0) {
			$data['read_more_1'] = "0";
		}else{
			$data['read_more_1'] = "1";
		}

		$result_read_more_2 = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'read_more_2'");
		if ($result_read_more_2->num_rows == 0) {
			$data['read_more_2'] = "0";
		}else{
			$data['read_more_2'] = "1";
		}

		$result_height_box_1 = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'height_box_1'");
		if ($result_height_box_1->num_rows == 0) {
			$data['height_box_1'] = "0";
		}else{
			$data['height_box_1'] = "1";
		}

		$result_height_box_2 = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'height_box_2'");
		if ($result_height_box_2->num_rows == 0) {
			$data['height_box_2'] = "0";
		}else{
			$data['height_box_2'] = "1";
		}

		$result_hide_box_1 = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'hide_box_1'");
		if ($result_hide_box_1->num_rows == 0) {
			$data['hide_box_1'] = "0";
		}else{
			$data['hide_box_1'] = "1";
		}

		$result_hide_box_2 = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'hide_box_2'");
		if ($result_hide_box_2->num_rows == 0) {
			$data['hide_box_2'] = "0";
		}else{
			$data['hide_box_2'] = "1";
		}

		$result_bottom_title = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category_description LIKE 'bottom_title'");
		if ($result_bottom_title->num_rows == 0) {
			$data['bottom_title'] = "0";
		}else{
			$data['bottom_title'] = "1";
		}
		
		$result_bottom_description = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category_description LIKE 'bottom_description'");
		if ($result_bottom_description->num_rows == 0) {
			$data['bottom_description'] = "0";
		}else{
			$data['bottom_description'] = "1";
		}

		if (isset($this->request->post['module_ad_category_icon_hide'])) {
			$data['module_ad_category_icon_hide'] = $this->request->post['module_ad_category_icon_hide'];
		} elseif (!empty($this->config->get('module_ad_category_icon_hide'))) {
			$data['module_ad_category_icon_hide'] = $this->config->get('module_ad_category_icon_hide');
		} else {
			$data['module_ad_category_icon_hide'] = 'fa fa-angle-up';
		}
		
		if (isset($this->request->post['module_ad_category_icon_show'])) {
			$data['module_ad_category_icon_show'] = $this->request->post['module_ad_category_icon_show'];
		} elseif (!empty($this->config->get('module_ad_category_icon_show'))) {
			$data['module_ad_category_icon_show'] = $this->config->get('module_ad_category_icon_show');
		} else {
			$data['module_ad_category_icon_show'] = 'fa fa-angle-down';
		}
		
		if (isset($this->request->post['module_ad_category_speed'])) {
			$data['module_ad_category_speed'] = $this->request->post['module_ad_category_speed'];
		} elseif (!empty($this->config->get('module_ad_category_speed'))) {
			$data['module_ad_category_speed'] = $this->config->get('module_ad_category_speed');
		} else {
			$data['module_ad_category_speed'] = 500;
		}
		
		if (isset($this->request->post['module_ad_category_status'])) {
			$data['module_ad_category_status'] = $this->request->post['module_ad_category_status'];
		} else {
			$data['module_ad_category_status'] = $this->config->get('module_ad_category_status');
		}

		if (isset($this->request->post['module_ad_category'])) {
			$data['module_ad_category'] = $this->request->post['module_ad_category'];
		} else {
			$data['module_ad_category'] = $this->config->get('module_ad_category');
		}		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/ad_category', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/ad_category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function install() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installReadMore1();
		$this->model_extension_module_ad_category->installReadMore2();
		$this->model_extension_module_ad_category->installHeightBox1();
		$this->model_extension_module_ad_category->installHeightBox2();
		$this->model_extension_module_ad_category->installHideBox1();
		$this->model_extension_module_ad_category->installHideBox2();
		$this->model_extension_module_ad_category->installBottomTitle();
		$this->model_extension_module_ad_category->installBottomDescription();	
	}
	
	public function installReadMore1() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installReadMore1();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function installReadMore2() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installReadMore2();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function installHeightBox1() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installHeightBox1();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function installHeightBox2() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installHeightBox2();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function installHideBox1() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installHideBox1();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function installHideBox2() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installHideBox2();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function installBottomTitle() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installBottomTitle();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function installBottomDescription() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->installBottomDescription();
		$this->session->data['install_db'] = $this->language->get('text_success_install_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstall() {
		$this->load->model('setting/extension');
		$this->model_setting_extension->uninstall('ad_category', $this->request->get['extension']);
		$this->load->model('setting/setting');
		$this->model_setting_setting->deleteSetting($this->request->get['extension']);
	}
	public function uninstallReadMore1() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallReadMore1();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstallReadMore2() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallReadMore2();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstallHeightBox1() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallHeightBox1();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstallHeightBox2() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallHeightBox2();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstallHideBox1() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallHideBox1();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstallHideBox2() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallHideBox2();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstallBottomTitle() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallBottomTitle();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
	public function uninstallBottomDescription() {
		$this->load->language('extension/module/ad_category');
		$this->load->model('extension/module/ad_category');
		$this->model_extension_module_ad_category->uninstallBottomDescription();
		$this->session->data['uninstall_db'] = $this->language->get('text_success_uninstall_db');
		$this->response->redirect($this->url->link('extension/module/ad_category', 'user_token=' . $this->session->data['user_token'], true));
	}
}