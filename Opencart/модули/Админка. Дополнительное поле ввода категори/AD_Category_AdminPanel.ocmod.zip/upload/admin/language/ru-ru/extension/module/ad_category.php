<?php
// Heading
$_['heading_title']				= 'Дополнительное Описание Категории';

// Text
$_['text_extension'] 			= 'Модули';
$_['text_success']				= 'Модуль успешно установлен!';
$_['text_edit']					= 'Редактирование модуля';
$_['text_status_success']		= 'Установлено';
$_['text_status_error']			= 'Не установлено';
$_['text_db']					= 'Все поля должны быть установлены в БД. Иначе модификатор будет работать некорректно!';
$_['text_speed']				= '500';
$_['text_icon_hide']			= 'fa fa-angle-up';
$_['text_icon_show']			= 'fa fa-angle-down';
$_['text_hide_text']			= 'Свернуть';
$_['text_show_text']			= 'Развернуть';

// Entry
$_['entry_speed']				= 'Скорость "Свернуть/Развернуть"';
$_['entry_status']				= 'Статус';
$_['entry_icon_hide']			= 'Class иконки "свернуть"';
$_['entry_icon_show']			= 'Class иконки "развернуть"';
$_['entry_hide_text']			= 'Текст "свернуть"';
$_['entry_show_text']			= 'Текст "развернуть"';

// Column
$_['column_name_db']			= 'Имя поля в бд';
$_['column_status_db']			= 'Статус';
$_['column_action_db']			= 'Действие';

// Tabs
$_['tab_general']				= 'Общие';
$_['tab_status_db']				= 'Статус БД';
$_['tab_info']					= 'О модуле';

// Button
$_['button_install']			= 'Установить';
$_['button_uninstall']			= 'Удалить';

//Help
$_['help_speed']				= 'Значение в миллисекундах';

// Error
$_['error_permission']			= 'У вас нет прав для управления модулем!';
$_['text_success_install_db']	= 'Поле в базу данных успешно установлено!';
$_['text_success_uninstall_db']	= 'Поле из базы данных успешно удалено!';

// Info
$_['entry_version']				= 'Версия';
$_['entry_support']				= 'Техническая поддержка';
$_['text_support']				= 'Отправить запрос в службу поддержки';
$_['entry_author']				= 'Разработчик';
$_['entry_documentation']		= 'Документация';