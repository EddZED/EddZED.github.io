<?php
// Entry
$_["entry_read_more_1"]			= "Collapse top descriptions";
$_["entry_read_more_2"]			= "Collapse bottom descriptions";
$_["entry_height_box_1"]		= "Height of the top description block";
$_["entry_height_box_2"]		= "Height of the bottom description block";
$_["entry_hide_box_1"]			= "Show top description on first page";
$_["entry_hide_box_2"]			= "Show bottom description on first page";
$_["entry_bottom_title"]		= "Title bottom descriptions";
$_["entry_bottom_description"]	= "Bottom description";

// Help
$_["help_read_more"]			= "Button 'Expand / Collapse' - unfolds the text completely.";
$_["help_hide_box_1"]			= "Display description and image only on the first page of categories?";
$_["help_hide_box_2"]			= "Display the bottom description only on the first page of categories?";
$_["help_bottom_description"]	= "It is displayed below under the goods";

// Text
$_["text_yes"]					= "Yes";
$_["text_no"] 					= "No";