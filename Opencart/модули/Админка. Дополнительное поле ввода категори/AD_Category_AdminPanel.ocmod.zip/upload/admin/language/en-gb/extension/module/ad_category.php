<?php
// Heading
$_['heading_title']				= 'Additional Description Categories';

// Text
$_['text_extension'] 			= 'Module';
$_['text_success']				= 'Success: You have modified module!';
$_['text_edit']					= 'Edit Module';
$_['text_status_success']		= 'Installed';
$_['text_status_error']			= 'Not installed';
$_['text_db']					= 'All fields must be set in the database. Otherwise, the modifier will not work correctly!';
$_['text_speed']				= '500';
$_['text_icon_hide']			= 'fa fa-angle-up';
$_['text_icon_show']			= 'fa fa-angle-down';
$_['text_hide_text']			= 'Collapse';
$_['text_show_text']			= 'Expand';

// Entry
$_['entry_speed']				= 'Speed "Collapse/Expand"';
$_['entry_status']				= 'Status';
$_['entry_icon_hide']			= 'Class icon "Collapse"';
$_['entry_icon_show']			= 'Class icon "Expand"';
$_['entry_hide_text']			= 'Text "Collapse"';
$_['entry_show_text']			= 'Text "Expand"';

// Column
$_['column_name_db']			= 'Field name in DB';
$_['column_status_db']			= 'Status';
$_['column_action_db']			= 'Action';

// Tabs
$_['tab_general']				= 'General';
$_['tab_status_db']				= 'Status DB';
$_['tab_info']					= 'Info';

// Button
$_['button_install']			= 'Install';
$_['button_uninstall']			= 'Uninstall';

//Help
$_['help_speed']				= 'Value in milliseconds';

// Error
$_['error_permission']			= 'Warning: You do not have permission to modify module!';
$_['text_success_install_db']	= 'The field in the database has been successfully installed!';
$_['text_success_uninstall_db']	= 'The field from the database was successfully deleted!';

// Info
$_['entry_version']				= 'Version';
$_['entry_support']				= 'Technical support';
$_['text_support']				= 'Send a request to the support team';
$_['entry_author']				= 'Developer';
$_['entry_documentation']		= 'Documentation';