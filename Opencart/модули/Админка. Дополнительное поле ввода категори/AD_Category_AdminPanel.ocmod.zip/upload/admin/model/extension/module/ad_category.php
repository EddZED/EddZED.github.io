<?php
class ModelExtensionModuleAdCategory extends Model {
	public function installReadMore1() {
		if($this->db->query("SHOW COLUMNS FROM `". DB_PREFIX . "category` LIKE 'read_more_1'")->num_rows ==0) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "category` ADD COLUMN `read_more_1` TINYINT(1) NOT NULL DEFAULT '0' AFTER `status`");
		}	
	}
	public function installReadMore2() {
		if($this->db->query("SHOW COLUMNS FROM `". DB_PREFIX . "category` LIKE 'read_more_2'")->num_rows ==0) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "category` ADD COLUMN `read_more_2` TINYINT(1) NOT NULL DEFAULT '0' AFTER `status`");
		}		
	}
	public function installHeightBox1() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'height_box_1'")->num_rows == 0) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category ADD COLUMN `height_box_1` INT(5) NOT NULL AFTER `status`");
		}		
	}
	public function installHeightBox2() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'height_box_2'")->num_rows == 0) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category ADD COLUMN `height_box_2` INT(5) NOT NULL AFTER `status`");
		}
	}
	public function installHideBox1() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'hide_box_1'")->num_rows == 0) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category ADD COLUMN `hide_box_1` TINYINT(1) NOT NULL DEFAULT '0' AFTER `status`");
		}
	}
	public function installHideBox2() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'hide_box_2'")->num_rows == 0) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category ADD COLUMN `hide_box_2` TINYINT(1) NOT NULL DEFAULT '0' AFTER `status`");
		}
	}
	public function installBottomTitle() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category_description LIKE 'bottom_title'")->num_rows == 0) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category_description ADD COLUMN `bottom_title` VARCHAR(255) NOT NULL AFTER `description`");
		}
	}
	public function installBottomDescription() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category_description LIKE 'bottom_description'")->num_rows == 0) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category_description ADD COLUMN `bottom_description` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL AFTER `description`");
		}
	}
	public function uninstallReadMore1() {
		if($this->db->query("SHOW COLUMNS FROM `". DB_PREFIX . "category` LIKE 'read_more_1'")->num_rows ==1) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "category` DROP `read_more_1`");
		}	
	}
	public function uninstallReadMore2() {
		if($this->db->query("SHOW COLUMNS FROM `". DB_PREFIX . "category` LIKE 'read_more_2'")->num_rows ==1) {
			$this->db->query("ALTER TABLE `" . DB_PREFIX . "category` DROP `read_more_2`");
		}		
	}
	public function uninstallHeightBox1() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'height_box_1'")->num_rows == 1) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category DROP `height_box_1`");
		}		
	}
	public function uninstallHeightBox2() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'height_box_2'")->num_rows == 1) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category DROP `height_box_2`");
		}
	}
	public function uninstallHideBox1() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'hide_box_1'")->num_rows == 1) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category DROP `hide_box_1`");
		}
	}
	public function uninstallHideBox2() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category LIKE 'hide_box_2'")->num_rows == 1) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category DROP `hide_box_2`");
		}
	}
	public function uninstallBottomTitle() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category_description LIKE 'bottom_title'")->num_rows == 1) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category_description DROP `bottom_title`");
		}
	}
	public function uninstallBottomDescription() {
		if ($this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category_description LIKE 'bottom_description'")->num_rows == 1) {
			$this->db->query("ALTER TABLE " . DB_PREFIX . "category_description DROP `bottom_description`");
		}
	}
}