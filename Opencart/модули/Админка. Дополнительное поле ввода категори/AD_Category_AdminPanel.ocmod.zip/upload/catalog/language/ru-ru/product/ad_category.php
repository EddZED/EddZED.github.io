<?php
// Text
$_['text_default_show_text'] = 'Развернуть <i class="fa fa-angle-down"></i>';
$_['text_default_hide_text'] = 'Свернуть <i class="fa fa-angle-up"></i>';