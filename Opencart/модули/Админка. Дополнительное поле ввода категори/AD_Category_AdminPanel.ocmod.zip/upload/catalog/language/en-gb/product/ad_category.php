<?php
// Text
$_['text_default_show_text'] = 'Expand <i class="fa fa-angle-down"></i>';
$_['text_default_hide_text'] = 'Collapse <i class="fa fa-angle-up"></i>';