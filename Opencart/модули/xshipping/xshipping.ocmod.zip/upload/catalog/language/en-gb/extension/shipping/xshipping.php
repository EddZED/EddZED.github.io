<?php
// Text
$_['text_title']       = 'X-Shipping';
$_['text_description'] = 'X-Shipping';
?>