<?php
// Heading
$_['page_title']    = 'Product variants';
$_['heading_title']    = '<a href="https://opencart3x.ru" target="_blank" title="Разработчик Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];

$_['text_module']      = 'Modules';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Product variants!';
$_['text_edit']        = 'Edit Product variants';

// Entry 
$_['entry_status']     = 'Status';

$_['entry_prodvar_title']    = 'Product variants Title';
$_['entry_prodvar_product_str_id']    = 'Product variants';
 
// Error 
$_['error_permission'] = 'Warning: You do not have permission to modify Product variants!';
$_['error_selectcheckbox'] = 'Select atleast 1 checkbox!';