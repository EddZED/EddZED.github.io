<?php
// Heading
$_['page_title']    = 'Варианты товаров';
$_['heading_title']    = '<a href="https://opencart3x.ru" target="_blank" title="Разработчик Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];

$_['text_module']      = 'Модули';
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки модуля успешно сохранены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry 
$_['entry_status']     = 'Статус';

$_['entry_prodvar_title']    = 'Заголовок вариантов';
$_['entry_prodvar_product_str_id']    = 'Варианты товаров';
 
// Error 
$_['error_permission'] = 'Ошибка! У вас нет доступа для управления молулем';
$_['error_selectcheckbox'] = 'Установите по крайней мере 1 флажок!';