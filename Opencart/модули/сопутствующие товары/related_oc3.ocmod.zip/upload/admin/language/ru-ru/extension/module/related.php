<?php
// Heading
$_['page_title']    = 'Сопутствующие товары';
$_['heading_title']    = '<a href="https://opencart3x.ru" target="_blank" title="Разработчик Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];

$_['text_module']      = 'Модули';
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки модуля успешно сохранены!';
$_['text_edit']        = 'Редактирование модуля';

// Entry 
$_['entry_status']     = 'Статус';

$_['entry_related_title']    = 'Заголовок сопутствующих';
$_['entry_related_product_str_id']    = 'Сопутствующие товары';
 
// Error 
$_['error_permission'] = 'Ошибка! У вас нет доступа для управления молулем';
$_['error_selectcheckbox'] = 'Установите по крайней мере 1 флажок!';