<?php
// Heading
$_['page_title']    = 'Related Products';
$_['heading_title']    = '<a href="https://opencart3x.ru" target="_blank" title="Разработчик Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];

$_['text_module']      = 'Modules';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Related Products!';
$_['text_edit']        = 'Edit Related Products';

// Entry 
$_['entry_status']     = 'Status';

$_['entry_related_title']    = 'Title Related';
$_['entry_related_product_str_id']    = 'Related Products';
 
// Error 
$_['error_permission'] = 'Warning: You do not have permission to modify Related Products!';
$_['error_selectcheckbox'] = 'Select atleast 1 checkbox!';