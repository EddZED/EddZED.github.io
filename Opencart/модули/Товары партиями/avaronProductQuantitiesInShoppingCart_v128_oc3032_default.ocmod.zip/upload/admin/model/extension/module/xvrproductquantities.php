<?php
class ModelExtensionModuleXvrproductquantities extends Model {

  // Запись настроек в базу данных
  public function SaveSettings() {
  $this->load->model('setting/setting');
  $this->model_setting_setting->editSetting('module_xvrproductquantities', $this->request->post);
  $this->model_setting_setting->editSetting('xvr_pm_product', $this->request->post);
	$this->model_setting_setting->editSetting('xvr_pm_featured_product', $this->request->post);
	$this->model_setting_setting->editSetting('xvr_pm_category', $this->request->post);
	$this->model_setting_setting->editSetting('xvr_pm_home', $this->request->post);
	$this->model_setting_setting->editSetting('xvr_pm_other', $this->request->post);
	$this->model_setting_setting->editSetting('xvr_pm_cart', $this->request->post);
  $this->model_setting_setting->editSetting('xvr_pm_vminus', $this->request->post);
  }

  // Загрузка настроек из базы данных
  public function LoadSettingsModul() {
  return $this->config->get('module_xvrproductquantities_status');
  }
  public function LoadSettingsProduct() {
	return $this->config->get('xvr_pm_product_status');
  }
  public function LoadSettingsFeaturedProduct() {
	return $this->config->get('xvr_pm_featured_product_status');
  }
  public function LoadSettingsCategory() {
	return $this->config->get('xvr_pm_category_status');
  }
  public function LoadSettingsHome() {
	return $this->config->get('xvr_pm_home_status');
  }
  public function LoadSettingsOther() {
	return $this->config->get('xvr_pm_other_status');
  }
  public function LoadSettingsCart() {
	return $this->config->get('xvr_pm_cart_status');
  }
  public function LoadSettingsVminus() {
  return $this->config->get('xvr_pm_vminus_status');
  }

}
?>