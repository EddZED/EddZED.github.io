<?php
// Heading
$_['heading_title']                = '<a href="https://gixoc.ru">GixOC.ru</a> - <b>Admin Security: reCaptcha / �������</b>';
$_['text_title']       	           = 'GixOC.ru - Admin Security: reCaptcha / �������';

// Text
$_['text_success']                 = 'Settings saved';
$_['text_extension']               = 'Modules';
$_['text_edit']                    = 'Settings';
$_['text_info_captcha']            = 'For correct work of captcha not forget to include it (<i>Extension/Captcha/Google reCAPTCHA</i>)!';

// Entry
$_['entry_status']                 = 'Status';

// Error
$_['error_permission']             = 'Warning: You do not have permission to modify this module!';