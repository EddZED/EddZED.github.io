<?php
// Heading
$_['heading_title']                = '<a href="https://gixoc.ru">GixOC.ru</a> - <b>Admin Security: reCaptcha / реКапча</b>';
$_['text_title']       	           = 'GixOC.ru - Admin Security: reCaptcha / реКапча';

// Text
$_['text_success']                 = 'Настройки сохранены!';
$_['text_extension']               = 'Модули';
$_['text_edit']                    = 'Настройки';
$_['text_info_captcha']            = 'Для корректной работы капчи не забываем <b>включить и настроить</b> её (<i>Дополнения/Captcha/Google reCAPTCHA</i>)!';

// Entry
$_['entry_status']                 = 'Статус';

// Error
$_['error_permission'] = 'У вас нет прав для управления этим модулем!';