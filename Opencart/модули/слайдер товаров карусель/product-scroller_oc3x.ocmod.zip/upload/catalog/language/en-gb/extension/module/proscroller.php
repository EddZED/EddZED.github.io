<?php
// Heading 
$_['heading_title']  = 'Product Scroller';

$_['text_reviews']  = '%s review(s)'; 
$_['text_tax']      = 'Ex Tax:';
?>