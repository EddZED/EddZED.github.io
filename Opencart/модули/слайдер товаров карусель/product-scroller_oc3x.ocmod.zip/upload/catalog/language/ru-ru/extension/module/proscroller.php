<?php
// Heading 
$_['heading_title']  = 'Скроллер';

$_['text_reviews']  = '%s отзыв(ов)'; 
$_['text_tax']      = 'Без НДС:';
?>