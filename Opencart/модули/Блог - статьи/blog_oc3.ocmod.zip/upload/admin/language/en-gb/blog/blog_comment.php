<?php
// Heading
$_['heading_title']       = 'Blog Comments';
// Text
$_['column_comment']       = 'Comment';
$_['column_post']       = 'Blog Post';
$_['column_name']       = 'Author';
$_['column_date']       = 'Date Added';
$_['column_status']       = 'Status';
$_['text_no_result']       = 'No results';
$_['text_enable']       = 'Enable';
$_['text_disable']       = 'Disable';

$_['entry_status']        = 'Status';



// Error
$_['error_permission']    = 'Warning: You do not have permission to modify blog comments';
$_['text_success']        = 'Success: You have modified blog comments';
