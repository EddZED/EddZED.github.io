<?php
// Heading
$_['page_title']    = 'Blog: Categories';
$_['heading_title']    = '<a href="http://opencart3x.ru" target="_blank" title="Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified blog category module';
$_['text_edit']        = 'Edit Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify blog category module';