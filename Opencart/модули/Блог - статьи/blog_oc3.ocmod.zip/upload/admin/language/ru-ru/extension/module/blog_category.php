<?php
// Heading
$_['page_title']    = 'Блог: Категории';
$_['heading_title']    = '<a href="http://opencart3x.ru" target="_blank" title="Разработчик Opencart3x.ru" style="color:#233746"><i class="fa fa-circle-o"></i></a> '. $_['page_title'];

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Успешно: Вы изменили модуль вывода категорий блога';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Ошибка: У вас нет доступа для изменения модуля';