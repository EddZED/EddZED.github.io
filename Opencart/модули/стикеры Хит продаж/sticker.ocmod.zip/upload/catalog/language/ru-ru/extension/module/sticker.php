<?php
// Text
$_['text_sticker_new']     		= "Новый";
$_['text_sticker_bestseller']   = "Хит";
$_['text_sticker_special']   	= "Акция";