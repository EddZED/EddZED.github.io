<?php
// Text
$_['text_sticker_new']     		= "New";
$_['text_sticker_bestseller']   = "Hit";
$_['text_sticker_special']   	= "Special";