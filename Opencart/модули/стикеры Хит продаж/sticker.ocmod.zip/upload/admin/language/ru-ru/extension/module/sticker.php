<?php 
// Heading
$_['heading_title'] 	    	= 'Стикеры';

// Text
$_['text_extension']   			= 'Расширения';
$_['text_success']     			= 'Настройки успешно изменены!';
$_['text_edit']        			= 'Настройки модуля';
$_['text_sticker_new']     		= 'Стикер: Новый';
$_['text_sticker_special']     	= 'Стикер: Акция';
$_['text_sticker_bestseller']	= 'Стикер: Хит продаж';
$_['text_sticker_stock']      	= 'Стикер: Отсутствие на складе';
$_['text_sticker_price']      	= 'Стикеры зависимые от цены';
$_['text_sticker_custom']      	= 'Пользовательские стикеры';
$_['text_date_added']     		= 'Дата добавления';
$_['text_date_available']     	= 'Дата поступления';
$_['text_label_percent'] 		= 'Процент по акции';
$_['text_label_text'] 			= 'Текст "Акция"';
$_['text_label_text_percent'] 	= 'Текст "Акция" и Процент по акции';
$_['text_left'] 				= 'Слева';
$_['text_right'] 				= 'Справа';
$_['text_star'] 				= 'Звёзда';
$_['text_rectangle'] 			= 'Прямоугольник';
$_['text_ribbon'] 				= 'Горизонтальная лента';
$_['text_diagonal'] 			= 'Диагональная лента';
$_['text_no_sticker'] 			= 'Стикеры для категорий начиная с этой версии поставляются отдельно. Модуль доступен для бесплатного скачивания: <a class="btn btn-default" href="https://seregin-pro.ru/component/phocadownload/category/1-extensions.html?download=12:category-sticker">Скачать</a>';

// Tab
$_['tab_product']   			= 'Товар';
$_['tab_category']   			= 'Категория';

// Entry
$_['entry_status'] 				= 'Статус';
$_['entry_date_new'] 			= 'Учитывать дату';
$_['entry_day'] 				= 'Считать товар новым (дней)';
$_['entry_sale'] 				= 'Считать товар хитом (количество продаж)';
$_['entry_label'] 				= 'Тип метки';
$_['entry_position'] 			= 'Отображение';
$_['entry_type'] 				= 'Тип стикера';
$_['entry_name'] 				= 'Название';
$_['entry_image'] 				= 'Изображение';
$_['entry_sort_order']       	= 'Порядок сортировки';
$_['entry_price']   			= 'Цена';
$_['entry_min']   				= 'Минимальная цена';
$_['entry_max']   				= 'Максимальная цена';
$_['entry_date']   				= 'Дата';
$_['entry_date_start']   		= 'Дата начала';
$_['entry_date_end']   			= 'Дата окончания';

// Button
$_['button_apply']   			= 'Применить';

// Error
$_['error_permission'] 			= 'У вас нет прав для управления данным модулем!';
$_['error_name']     			= 'Введите название стикера!';