<?php
// Text
$_['tab_sticker'] = "Стикеры";