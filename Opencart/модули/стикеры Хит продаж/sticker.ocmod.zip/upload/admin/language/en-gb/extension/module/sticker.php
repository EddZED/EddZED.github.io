<?php
// Heading
$_['heading_title'] 	    	= 'Stickers';

// Text
$_['text_extension']   			= 'Extensions';
$_['text_success']     			= 'Success: You have modified Product Sticker module!';
$_['text_edit']        			= 'Edit Product Sticker Module';
$_['text_general']   			= 'General';
$_['text_sticker_new']     		= 'Sticker: New';
$_['text_sticker_special']     	= 'Sticker: Special';
$_['text_sticker_bestseller']	= 'Sticker: Bestseller';
$_['text_sticker_stock']      	= 'Sticker: Out of Stock';
$_['text_sticker_price']      	= 'Sticker: Price';
$_['text_date_added']     		= 'Date added';
$_['text_date_available']     	= 'Date available';
$_['text_sticker_custom']      	= 'Custom Stickers';
$_['text_label_percent'] 		= 'Percent';
$_['text_label_text'] 			= 'Text Special"';
$_['text_label_text_percent'] 	= 'Text Special and percent';
$_['text_left'] 				= 'Left';
$_['text_right'] 				= 'Right';
$_['text_star'] 				= 'Circle';
$_['text_rectangle'] 			= 'Rectangle';
$_['text_ribbon'] 				= 'Ribbon';
$_['text_diagonal'] 			= 'Diagonal ribbon';
$_['text_no_sticker'] 			= 'Category Sticker removed from this module. You can free download it: <a class="btn btn-default" href="https://seregin-pro.ru/component/phocadownload/category/1-extensions.html?download=12:category-sticker">Download</a>';

// Tab
$_['tab_product']   			= 'Product';
$_['tab_category']   			= 'Category';

// Entry
$_['entry_status'] 				= 'Status';
$_['entry_date_new'] 			= 'Use date';
$_['entry_day'] 				= 'New Products (days)';
$_['entry_sale'] 				= 'Bestseller Products (number of sales)';
$_['entry_label'] 				= 'Type label';
$_['entry_position'] 			= 'Position';
$_['entry_type'] 				= 'Type sticker';
$_['entry_name'] 				= 'Name';
$_['entry_image'] 				= 'Image';
$_['entry_sort_order']       	= 'Sort Order';
$_['entry_price']   			= 'Price';
$_['entry_min']   				= 'Min price';
$_['entry_max']   				= 'Max price';
$_['entry_date']   				= 'Date';
$_['entry_date_start']   		= 'Date start';
$_['entry_date_end']   			= 'Date end';

// Button
$_['button_apply']   			= 'Apply';

// Error
$_['error_permission'] 			= 'Warning: You do not have permission to modify module!';	
$_['error_name']      			= 'Name required!';