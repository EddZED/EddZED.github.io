<?php
class ModelCatalogMyLabelProduct extends Model {
	public function getProductLabel($product_id) {
		$query = $this->db->query("SELECT * FROM oca_label_product olp LEFT JOIN oca_label ol ON (olp.label_id = ol.label_id) WHERE olp.product_id = '" . (int)$product_id . "' AND (olp.date_start = '0000-00-00' OR olp.date_start < NOW()) AND (olp.date_end = '0000-00-00' OR olp.date_end > NOW())");

		return $query->rows;

	}
}
?>