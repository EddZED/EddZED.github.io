// Действия при нажатии кнопки ПЛЮС
var xvrPlus = function (oldValueXVR, newValueXVR, stepValueXVR, minValueXVR, maxValueXVR, quantityInStock, textAlertMinimum, textAlertMaximumOrder, textAlertQuantityInStock, textAlertQuantityInOrder, textAlertOrderNotAvailable, textCheckForNumber, xvrPmVminusStatus, xvrProductName) {
	if(isNaN(oldValueXVR) == false) {
		if (xvrPmVminusStatus == 1) {
			if (oldValueXVR == 0 && quantityInStock < minValueXVR)
			{
				xvrModalAlert(xvrProductName, textAlertOrderNotAvailable + '<br><br>' + textAlertQuantityInOrder + oldValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
				return oldValueXVR;
			} else {
					newValueXVR = minValueXVR;
					for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
					{
						newValueXVR = newValueXVR + stepValueXVR;
					}
					if (oldValueXVR >= newValueXVR)
					{
						newValueXVR = newValueXVR + stepValueXVR;
					}
					if (newValueXVR > quantityInStock && newValueXVR <= maxValueXVR)
					{
						newValueXVR = minValueXVR;
						for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
						{
							newValueXVR = newValueXVR + stepValueXVR;
						};
						xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
					}
					if (newValueXVR > maxValueXVR && maxValueXVR <= quantityInStock)
					{
						newValueXVR = maxValueXVR;
						xvrModalAlert(xvrProductName, textAlertMaximumOrder + maxValueXVR/1000);
					}
					if (newValueXVR > maxValueXVR && maxValueXVR > quantityInStock)
					{
						newValueXVR = minValueXVR;
						for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
						{
							newValueXVR = newValueXVR + stepValueXVR;
						};
						xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
					}
				return newValueXVR;
			}
		}
		if (xvrPmVminusStatus != 1) {
				newValueXVR = minValueXVR;
				for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
				{
					newValueXVR = newValueXVR + stepValueXVR;
				}
				if (oldValueXVR >= newValueXVR)
				{
					newValueXVR = newValueXVR + stepValueXVR;
				}
				if (newValueXVR > maxValueXVR && maxValueXVR <= quantityInStock)
				{
					newValueXVR = maxValueXVR;
					xvrModalAlert(xvrProductName, textAlertMaximumOrder + maxValueXVR/1000);
				}
				if (newValueXVR > maxValueXVR && maxValueXVR > quantityInStock)
				{
					newValueXVR = maxValueXVR;
					xvrModalAlert(xvrProductName, textAlertMaximumOrder + maxValueXVR/1000);
				}
			return newValueXVR;
		}
	} else {
		xvrModalAlert(xvrProductName, textCheckForNumber);
		return newValueXVR;
	}
}
// Действия при нажатии кнопки МИНУС
var xvrMinus = function (oldValueXVR, newValueXVR, stepValueXVR, minValueXVR, maxValueXVR, quantityInStock, textAlertMinimum, textAlertMaximumOrder, textAlertQuantityInStock, textAlertQuantityInOrder, textAlertOrderNotAvailable, textCheckForNumber, xvrPmVminusStatus, xvrProductName) {
	if(isNaN(oldValueXVR) == false) {
		newValueXVR = minValueXVR;
		if (oldValueXVR <= maxValueXVR && oldValueXVR <= quantityInStock) {
			for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			}
			if ((oldValueXVR - newValueXVR) > 0)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			}
		}
	if (xvrPmVminusStatus == 1)
	{
		if (oldValueXVR <= maxValueXVR && oldValueXVR > quantityInStock) {
			for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			}
			if ((oldValueXVR - newValueXVR) > 0)
			{
				xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
				return newValueXVR;
			}
		}
	}
	if (xvrPmVminusStatus != 1)
	{
		if (oldValueXVR <= maxValueXVR && oldValueXVR > quantityInStock) {
			for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			}
			if ((oldValueXVR - newValueXVR) > 0)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			}
		}
	}
		if (oldValueXVR > maxValueXVR && maxValueXVR <= quantityInStock) {
			newValueXVR = maxValueXVR + stepValueXVR;
			xvrModalAlert(xvrProductName, textAlertMaximumOrder + maxValueXVR/1000);
		}
	if (xvrPmVminusStatus != 1)
	{
		if (oldValueXVR > maxValueXVR && maxValueXVR > quantityInStock) {
			newValueXVR = maxValueXVR + stepValueXVR;
			xvrModalAlert(xvrProductName, textAlertMaximumOrder + maxValueXVR/1000);
		}
	}
	if (xvrPmVminusStatus == 1)
	{
		if (oldValueXVR > maxValueXVR && maxValueXVR > quantityInStock) {
			for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			}
			if ((oldValueXVR - newValueXVR) > 0)
			{
				xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
				return newValueXVR;
			}
		}
	}
		if (newValueXVR >= minValueXVR + stepValueXVR)
		{
			newValueXVR = newValueXVR - stepValueXVR;
			return newValueXVR;
		} else {
			xvrModalAlert(xvrProductName, textAlertMinimum + minValueXVR/1000);
			if (oldValueXVR == 0 && quantityInStock < minValueXVR) {return oldValueXVR;} else {return minValueXVR;}
		}
	} else {
		xvrModalAlert(xvrProductName, textCheckForNumber);
		return newValueXVR;
	}
}



// Выводим окно сообщения о возможном количестве товара для заказа
var xvrModalAlert = function (xvrProductName, alert_text) {
$('#modal-cart').remove();

html  = '<div id="modal-cart" class="modal fade" data-backdrop="static">';
html += 	'<div class="modal-dialog">';
html +=			'<div class="modal-content">';
html +=				'<div class="modal-header text-center" id="ModalAlert_1_header">';
//html +=					'<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>';
html +=					xvrProductName;
html +=				'</div>';
html +=				'<div class="modal-body text-center" id="ModalAlert_1_body">';
html +=					alert_text;
html +=				'</div>';
//html +=				'<div class="modal-footer" id="ModalAlert_1_footer">';
html +=				'<div class="modal-body text-center" id="ModalAlert_1_footer">';
html +=					'<button type="button" class="btn btn-primary" data-dismiss="modal" aria-hidden="true">Ок</button>';
html +=				'</div>';
html +=			'</div>';
html +=		'</div>';
html +=	'</div>';


$('html body').append(html);
$('#modal-cart').modal('show');
}



// Проверяем (при нажатии кнопки КУПИТЬ) на корректность количество, введенное вручную в поле input Карточки товара
var xvrCheckForCorrectInput = function (this_button, product_id) {
var oldValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('.input-quantity-XVR').val().replace(',','.'))*1000).toFixed(0));
var oldValueXVRvalidate = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-quantity-validate"]').val())*1000).toFixed(0));
var minValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-minimum"]').val())*1000).toFixed(0));
var newValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-minimum"]').val())*1000).toFixed(0));
var stepValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-order_step"]').val())*1000).toFixed(0));
var maxValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-maximum_order"]').val())*1000).toFixed(0));
var quantityInStock = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-quantity_in_stock"]').val())*1000).toFixed(0));
var xvrPmVminusStatus = $(this_button).parent().parent().find('input[name="xvr_pm_vminus_status"]').val();
var textAlertMinimum = $(this_button).parent().parent().find('input[name="text_alert_minimum"]').val();
var textAlertMaximumOrder = $(this_button).parent().parent().find('input[name="text_alert_maximum_order"]').val();
var textAlertQuantityInStock = $(this_button).parent().parent().find('input[name="text_alert_quantity_in_stock"]').val();
var textAlertQuantityInOrder = $(this_button).parent().parent().find('input[name="text_alert_quantity_in_order"]').val();
var textAlertOrderNotAvailable = $(this_button).parent().parent().find('input[name="text_alert_order_not_available"]').val();
var textOrderStep = $(this_button).parent().parent().find('input[name="text_order_step"]').val();
var textAlertOrderStep = $(this_button).parent().parent().find('input[name="text_alert_order_step"]').val();
var textAlertOror = $(this_button).parent().parent().find('input[name="text_alert_oror"]').val();
var textCheckForNumber = $(this_button).parent().parent().find('input[name="text_check_for_number"]').val();
var xvrProductName = $(this_button).parent().parent().find('input[name="xvr_product_name"]').val();

if (stepValueXVR == 0) {stepValueXVR = 1*1000;} else {};
if (maxValueXVR == 0) {maxValueXVR = Infinity;} else {};
if (quantityInStock == 0 && xvrPmVminusStatus == 1) {oldValueXVR = 0;} else {};

if(oldValueXVR!="" && isNaN(oldValueXVR) == false && oldValueXVR!=0) {

if (oldValueXVR < minValueXVR) {
	if (quantityInStock >= minValueXVR) {
		$(this_button).parent().parent().find('.input-quantity-XVR').val(minValueXVR/1000).change();
		$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(minValueXVR/1000).change();
		xvrModalAlert(xvrProductName, textAlertMinimum + minValueXVR/1000);
		return 1;
	} else {
		$(this_button).parent().parent().find('.input-quantity-XVR').val(0).change();
		$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(0).change();
		xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
		return 1;
	};
};

if (minValueXVR <= oldValueXVR && oldValueXVR <= maxValueXVR) {
	if (xvrPmVminusStatus == 1)
	{
		if (oldValueXVR > quantityInStock && quantityInStock >= minValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
			xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
			return 1;
		};
	};
	if (xvrPmVminusStatus != 1)
	{
		if (quantityInStock < oldValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
			if (stepValueXVR > 1 && newValueXVR != oldValueXVR) {
			xvrModalAlert(xvrProductName, textOrderStep + stepValueXVR/1000 + '<br><br>' + textAlertOrderStep + newValueXVR/1000 + textAlertOror + (newValueXVR/1000+stepValueXVR/1000));
			return 1;
			};
		};
	};
	if (quantityInStock >= oldValueXVR) {
		for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
		{
			newValueXVR = newValueXVR + stepValueXVR;
		};
		$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
		$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
		if (stepValueXVR > 1 && newValueXVR != oldValueXVR) {
		xvrModalAlert(xvrProductName, textOrderStep + stepValueXVR/1000 + '<br><br>' + textAlertOrderStep + newValueXVR/1000 + textAlertOror + (newValueXVR/1000+stepValueXVR/1000));
		return 1;
		};
		if (xvrPmVminusStatus == 1)
		{
			if (quantityInStock < minValueXVR) {
				$(this_button).parent().parent().find('.input-quantity-XVR').val(0).change();
				$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(0).change();
				xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
				return 1;
			};
		};						
	};
};

if (oldValueXVR > maxValueXVR) {
	if (maxValueXVR <= quantityInStock) {
		for (var i = minValueXVR + stepValueXVR; i <= maxValueXVR; i = i + stepValueXVR)
		{
			newValueXVR = newValueXVR + stepValueXVR;
		};
		$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
		$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
		xvrModalAlert(xvrProductName, textAlertMaximumOrder + newValueXVR/1000);
		return 1;
	};
	if (xvrPmVminusStatus != 1)
	{	
		if (maxValueXVR > quantityInStock) {
			for (var i = minValueXVR + stepValueXVR; i <= maxValueXVR; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
			xvrModalAlert(xvrProductName, textAlertMaximumOrder + newValueXVR/1000);
			return 1;
		};
	};
	if (xvrPmVminusStatus == 1)
	{
		if (maxValueXVR > quantityInStock && quantityInStock >= minValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
			xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
			return 1;
		};
		if (quantityInStock < minValueXVR) {
			$(this_button).parent().parent().find('.input-quantity-XVR').val(0).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(0).change();
			xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
			return 1;
		};
	};
};

} else {
	$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
	$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
	xvrModalAlert(xvrProductName, textCheckForNumber);
	return 1;
};
}




// Проверяем (при нажатии кнопки КУПИТЬ) на корректность количество, введенное вручную в поле input РАЗНОГО
var xvrCheckForCorrectInputOther = function (this_button, product_id) {
var oldValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('.input-quantity-XVR').val().replace(',','.'))*1000).toFixed(0));
var oldValueXVRvalidate = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-quantity-validate"]').val())*1000).toFixed(0));
var minValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-minimum"]').val())*1000).toFixed(0));
var newValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-minimum"]').val())*1000).toFixed(0));
var stepValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-order_step"]').val())*1000).toFixed(0));
var maxValueXVR = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-maximum_order"]').val())*1000).toFixed(0));
var quantityInStock = Math.round((parseFloat($(this_button).parent().parent().find('input[id="input-quantity_in_stock"]').val())*1000).toFixed(0));
var xvrPmVminusStatus = $(this_button).parent().parent().find('input[name="xvr_pm_vminus_status"]').val();
var textAlertMinimum = $(this_button).parent().parent().find('input[name="text_alert_minimum"]').val();
var textAlertMaximumOrder = $(this_button).parent().parent().find('input[name="text_alert_maximum_order"]').val();
var textAlertQuantityInStock = $(this_button).parent().parent().find('input[name="text_alert_quantity_in_stock"]').val();
var textAlertQuantityInOrder = $(this_button).parent().parent().find('input[name="text_alert_quantity_in_order"]').val();
var textAlertOrderNotAvailable = $(this_button).parent().parent().find('input[name="text_alert_order_not_available"]').val();
var textOrderStep = $(this_button).parent().parent().find('input[name="text_order_step"]').val();
var textAlertOrderStep = $(this_button).parent().parent().find('input[name="text_alert_order_step"]').val();
var textAlertOror = $(this_button).parent().parent().find('input[name="text_alert_oror"]').val();
var textCheckForNumber = $(this_button).parent().parent().find('input[name="text_check_for_number"]').val();
var xvrProductName = $(this_button).parent().parent().find('input[name="xvr_product_name"]').val();

if (stepValueXVR == 0) {stepValueXVR = 1*1000;} else {};
if (maxValueXVR == 0) {maxValueXVR = Infinity;} else {};
if (quantityInStock == 0 && xvrPmVminusStatus == 1) {oldValueXVR = 0;} else {};

if(oldValueXVR!="" && isNaN(oldValueXVR) == false && oldValueXVR!=0) {

if (oldValueXVR < minValueXVR) {
if (quantityInStock >= minValueXVR) {
	$(this_button).parent().parent().find('.input-quantity-XVR').val(minValueXVR/1000).change();
	$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(minValueXVR/1000).change();
	xvrModalAlert(xvrProductName, textAlertMinimum + (minValueXVR/1000));
	return;
} else {
	$(this_button).parent().parent().find('.input-quantity-XVR').val(0).change();
	$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(0).change();
	xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
	return;
};
};

if (minValueXVR <= oldValueXVR && oldValueXVR <= maxValueXVR) {
	if (xvrPmVminusStatus == 1)
	{
		if (oldValueXVR > quantityInStock && quantityInStock >= minValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
			xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
			return;
		};
	};
	if (xvrPmVminusStatus == 0)
	{
		if (quantityInStock < oldValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
			if (stepValueXVR > 1 && newValueXVR != oldValueXVR) {
			xvrModalAlert(xvrProductName, textOrderStep + stepValueXVR/1000 + '<br><br>' + textAlertOrderStep + (newValueXVR/1000) + textAlertOror + (newValueXVR/1000+stepValueXVR/1000));
			return;
			};
		};		
	};
	if (quantityInStock >= oldValueXVR) {
		for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
		{
			newValueXVR = newValueXVR + stepValueXVR;
		};
		$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
		$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
		if (stepValueXVR > 1 && newValueXVR != oldValueXVR) {
		xvrModalAlert(xvrProductName, textOrderStep + stepValueXVR/1000 + '<br><br>' + textAlertOrderStep + (newValueXVR/1000) + textAlertOror + (newValueXVR/1000+stepValueXVR/1000));
		return;
		};
	};
	if (xvrPmVminusStatus == 1)
	{
		if (quantityInStock < minValueXVR) {
			$(this_button).parent().parent().find('.input-quantity-XVR').val(0).change();
			$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(0).change();
			xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
			return;
		};
	};						
};

if (oldValueXVR > maxValueXVR) {
if (maxValueXVR <= quantityInStock) {
	for (var i = minValueXVR + stepValueXVR; i <= maxValueXVR; i = i + stepValueXVR)
	{
		newValueXVR = newValueXVR + stepValueXVR;
	};
	$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
	$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
	xvrModalAlert(xvrProductName, textAlertMaximumOrder + (newValueXVR/1000));
	return;
};
if (maxValueXVR > quantityInStock && quantityInStock >= minValueXVR) {
	for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
	{
		newValueXVR = newValueXVR + stepValueXVR;
	};
	$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
	$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
	xvrModalAlert(xvrProductName, textAlertQuantityInOrder + (newValueXVR/1000) + '<br><br>' + textAlertQuantityInStock + (quantityInStock/1000));
	return;
};
if (quantityInStock < minValueXVR) {
	$(this_button).parent().parent().find('.input-quantity-XVR').val(0).change();
	$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(0).change();
	xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
	return;
};
};
} else {
$(this_button).parent().parent().find('.input-quantity-XVR').val(newValueXVR/1000).change();
$(this_button).parent().parent().find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change();
xvrModalAlert(xvrProductName, textCheckForNumber);
return;
};

cart.add(product_id, oldValueXVR/1000);

}



// КОРЗИНА СТАНДАРТНАЯ Проверяем (при выходе из input (потеря фокуса)) на корректность количество, введенное вручную в поле input
var xvrCheckForCorrectInputCart = function (this_button) {
var oldValueXVR = Math.round((parseFloat($(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val().replace(',','.'))*1000).toFixed(0));
var oldValueXVRvalidate = Math.round((parseFloat($(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val())*1000).toFixed(0));
var minValueXVR = Math.round((parseFloat($(this_button).closest('.number-spinner-XVR').find('input[id="input-minimum"]').val())*1000).toFixed(0));
var newValueXVR = Math.round((parseFloat($(this_button).closest('.number-spinner-XVR').find('input[id="input-minimum"]').val())*1000).toFixed(0));
var stepValueXVR = Math.round((parseFloat($(this_button).closest('.number-spinner-XVR').find('input[id="input-order_step"]').val())*1000).toFixed(0));
var maxValueXVR = Math.round((parseFloat($(this_button).closest('.number-spinner-XVR').find('input[id="input-maximum_order"]').val())*1000).toFixed(0));
var quantityInStock = Math.round((parseFloat($(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity_in_stock"]').val())*1000).toFixed(0));
var xvrPmVminusStatus = $(this_button).closest('.number-spinner-XVR').find('input[name="xvr_pm_vminus_status"]').val();
var textAlertMinimum = $(this_button).closest('.number-spinner-XVR').find('input[name="text_alert_minimum"]').val();
var textAlertMaximumOrder = $(this_button).closest('.number-spinner-XVR').find('input[name="text_alert_maximum_order"]').val();
var textAlertQuantityInStock = $(this_button).closest('.number-spinner-XVR').find('input[name="text_alert_quantity_in_stock"]').val();
var textAlertQuantityInOrder = $(this_button).closest('.number-spinner-XVR').find('input[name="text_alert_quantity_in_order"]').val();
var textAlertOrderNotAvailable = $(this_button).closest('.number-spinner-XVR').find('input[name="text_alert_order_not_available"]').val();
var textOrderStep = $(this_button).closest('.number-spinner-XVR').find('input[name="text_order_step"]').val();
var textAlertOrderStep = $(this_button).closest('.number-spinner-XVR').find('input[name="text_alert_order_step"]').val();
var textAlertOror = $(this_button).closest('.number-spinner-XVR').find('input[name="text_alert_oror"]').val();
var textCheckForNumber = $(this_button).closest('.number-spinner-XVR').find('input[name="text_check_for_number"]').val();
var xvrProductName = $(this_button).closest('.number-spinner-XVR').find('input[name="xvr_product_name"]').val();

if (stepValueXVR == 0) {stepValueXVR = 1*1000;} else {};
if (maxValueXVR == 0) {maxValueXVR = Infinity;} else {};
if (quantityInStock == 0 && xvrPmVminusStatus == 1) {oldValueXVR = 0;} else {};

if(oldValueXVR!="" && isNaN(oldValueXVR) == false && oldValueXVR!=0) {

if (oldValueXVR < minValueXVR) {
	if (quantityInStock >= minValueXVR) {
		$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(minValueXVR/1000).change().focus();
		$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(minValueXVR/1000).change().focus();
		xvrModalAlert(xvrProductName, textAlertMinimum + minValueXVR/1000);
		return;
	} else {
		$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(0).change().focus();
		$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(0).change().focus();
		xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
		return;
	};
};

if (minValueXVR <= oldValueXVR && oldValueXVR <= maxValueXVR) {
	if (xvrPmVminusStatus == 1)
	{
		if (oldValueXVR > quantityInStock && quantityInStock >= minValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(newValueXVR/1000).change().focus();
			$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change().focus();
			xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
			return;
		};
	};
	if (xvrPmVminusStatus != 1)
	{
		if (quantityInStock < oldValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			if (stepValueXVR > 1 && newValueXVR != oldValueXVR) {
			$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(newValueXVR/1000).change().focus();
			$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change().focus();
			xvrModalAlert(xvrProductName, textOrderStep + stepValueXVR/1000 + '<br><br>' + textAlertOrderStep + newValueXVR/1000 + textAlertOror + (newValueXVR/1000+stepValueXVR/1000));
			return;
			};
		};
	};
	if (quantityInStock >= oldValueXVR) {
		for (var i = minValueXVR + stepValueXVR; i <= oldValueXVR; i = i + stepValueXVR)
		{
			newValueXVR = newValueXVR + stepValueXVR;
		};
		if (stepValueXVR > 1 && newValueXVR != oldValueXVR) {
		$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(newValueXVR/1000).change().focus();
		$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change().focus();
		xvrModalAlert(xvrProductName, textOrderStep + stepValueXVR/1000 + '<br><br>' + textAlertOrderStep + newValueXVR/1000 + textAlertOror + (newValueXVR/1000+stepValueXVR/1000));
		return;
		};
		if (xvrPmVminusStatus == 1)
		{
			if (quantityInStock < minValueXVR) {
				$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(0).change().focus();
				$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(0).change().focus();
				xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
				return;
			};
		};						
	};
};

if (oldValueXVR > maxValueXVR) {
	if (maxValueXVR <= quantityInStock) {
		for (var i = minValueXVR + stepValueXVR; i <= maxValueXVR; i = i + stepValueXVR)
		{
			newValueXVR = newValueXVR + stepValueXVR;
		};
		$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(newValueXVR/1000).change().focus();
		$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change().focus();
		xvrModalAlert(xvrProductName, textAlertMaximumOrder + newValueXVR/1000);
		return;
	};
	if (xvrPmVminusStatus != 1)
	{	
		if (maxValueXVR > quantityInStock) {
			for (var i = minValueXVR + stepValueXVR; i <= maxValueXVR; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(newValueXVR/1000).change().focus();
			$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change().focus();
			xvrModalAlert(xvrProductName, textAlertMaximumOrder + newValueXVR/1000);
			return;
		};
	};
	if (xvrPmVminusStatus == 1)
	{
		if (maxValueXVR > quantityInStock && quantityInStock >= minValueXVR) {
			for (var i = minValueXVR + stepValueXVR; i <= quantityInStock; i = i + stepValueXVR)
			{
				newValueXVR = newValueXVR + stepValueXVR;
			};
			$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(newValueXVR/1000).change().focus();
			$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change().focus();
			xvrModalAlert(xvrProductName, textAlertQuantityInOrder + newValueXVR/1000 + '<br><br>' + textAlertQuantityInStock + quantityInStock/1000);
			return;
		};
		if (quantityInStock < minValueXVR) {
			$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(0).change().focus();
			$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(0).change().focus();
			xvrModalAlert(xvrProductName, textAlertOrderNotAvailable);
			return;
		};
	};
};

} else {
	$(this_button).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(newValueXVR/1000).change().focus();
	$(this_button).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(newValueXVR/1000).change().focus();
	xvrModalAlert(xvrProductName, textCheckForNumber);
	return;
};
}



// Проверяем, не вводит ли клиент с клавиатуры буквы и другие символы в поле input карточки товара
var xvrCheckForCorrectInput2 = function (this_input) {
var oldValueXVR = $(this_input).closest('.number-spinner-XVR').find('.input-quantity-XVR').val().replace(',','.');
var oldValueXVRvalidate = $(this_input).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val();
var minValueXVR = $(this_input).closest('.number-spinner-XVR').find('input[id="input-minimum"]').val();

if(isNaN(oldValueXVR) == false) {
	$(this_input).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(oldValueXVR).change();
	$(this_input).closest('.number-spinner-XVR').find('input[id="input-quantity-validate"]').val(oldValueXVR).change();
	return;
} else {
	$(this_input).closest('.number-spinner-XVR').find('.input-quantity-XVR').val(oldValueXVRvalidate).change();
	return;
};
}
