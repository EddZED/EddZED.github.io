<?php
$_['entry_email']                  = 'E-Mail:';
$_['entry_password']               = 'Пароль:';
$_['text_register']                = 'Регистрация';
$_['text_forgotten']               = 'Забыли пароль?';
$_['text_login']       = 'Вход';
$_['text_logout']      = 'Выход';
$_['text_account']     = 'Моя информация';
$_['text_my_account']    = 'Мой аккаунт';
$_['text_my_orders']     = 'Мои заказы';
$_['text_my_newsletter'] = 'Подписка на рассылку';
$_['text_edit']        = 'Изменить контактную информацию';
$_['text_password']    = 'Пароль';
$_['text_wishlist']    = 'Закладки';
$_['text_order']       = 'История заказов';
$_['text_download']    = 'Файлы для скачивания';
$_['text_return']      = 'Возвраты';
$_['text_transaction'] = 'История фин. операций';
$_['text_newsletter']  = 'E-Mail рассылка';
$_['heading_title1']  = 'Авторизация';
$_['heading_title2']  = 'через соц.сети';
$_['text_skip']  = 'пропустить';
?>