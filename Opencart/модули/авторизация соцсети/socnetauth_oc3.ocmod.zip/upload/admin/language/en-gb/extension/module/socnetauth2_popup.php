<?php
// Heading
$_['page_title']                = 'Авторизация через соцсети - всплывающее окно';
$_['heading_title']    = '<a href="https://prowebber.ru/" target="_blank" title="ProWebber" style="color:#0362B6;margin-right:5px"><i class="fa fa-cloud-download fa-fw"></i></a> 
'. $_['page_title'];

?>