<?php
$_['text_price_for_others'] = 'Цены для других групп:';
?>