<?php
$_['text_price_for_others'] = 'Price for other groups:';
?>