<?php
// Heading
$_['heading_title']      = 'История транзакций';

// Column
$_['column_date_added']  = 'Добавлено';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Сумма (%s)';

// Text
$_['text_account']       = 'Личный Кабинет';
$_['text_transaction']   = 'Ваши транзакции';
$_['text_total']         = 'Ваш текущий баланс';
$_['text_empty']         = 'У Вас не было транзакций!';

