<?php
class ModelExtensionPaymentYandexpluspluscard extends Model {
	private $key;
	
	public function encrypt($value, $key) {
		return $value;
	}
	
	public function decrypt($value, $key) {
		return $value;
	}
}
?>