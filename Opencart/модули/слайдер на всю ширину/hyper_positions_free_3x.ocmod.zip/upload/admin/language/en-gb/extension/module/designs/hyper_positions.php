<?php
//
$_['hp_name_titles']			= 'SUPPORT AND UPGRADES';
$_['hp_name']					= 'HYPER POSITIONS';
$_['width_name']				= '100%';
$_['width_title']				= 'Width 100%';
$_['text_pos_left_center']		= 'Left center';
$_['text_pos_center']			= 'Central column';
$_['text_pos_right_center']		= 'Right center';
// TOP
$_['text_pos_sliders']			= 'SLIDESHOW';
// CONTENT
$_['text_content_pos']			= 'MAIN CONTENT';
$_['text_banner2_pos']			= 'BANNER 2';
$_['text_content2_pos']			= 'CONTENT 2';
// BOTTOM
$_['text_bottom_pos']			= 'BOTTOM UNIT';
// FOOTER
$_['text_map_pos']				= 'MAP';
//
$_['text_footers']				= 'FOOTER';