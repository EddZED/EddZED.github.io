<?php
// Heading
$_['heading_title']		= '<span style="color:darkblue;font-size:16px;"><i class="fa fa-th"></i> <b>HYPER POSITIONS</b></span>';
$_['header_title']		= 'HYPER POSITIONS';
$_['head_title']		= '<span style="color:darkblue;"><i class="fa fa-th"></i> <b>HYPER POSITIONS</b></span>';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified account module!';
$_['text_edit']        = 'Edit Account Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify account module!';