<?php
//
$_['hp_name_titles']			= 'Поддержка и обновление';
$_['hp_name']					= 'HYPER POSITIONS';
$_['width_name']				= '100%';
$_['width_title']				= 'На всю ширину';
$_['text_pos_left_center']		= 'Левый центр';
$_['text_pos_center']			= 'Центр';
$_['text_pos_right_center']		= 'Правый центр';
// TOP
$_['text_pos_sliders']			= 'Слайдер';
// CONTENT
$_['text_content_pos']			= 'Блок по умолчанию';
$_['text_banner2_pos']			= 'Блок банер';
$_['text_content2_pos']			= 'Средний блок';
$_['text_bottom_pos']			= 'Нижний блок';
// FOOTER
$_['text_map_pos']				= 'Карта';
