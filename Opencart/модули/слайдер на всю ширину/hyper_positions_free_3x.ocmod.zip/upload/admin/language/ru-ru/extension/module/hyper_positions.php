<?php
// Heading
$_['heading_title']		= '<span style="color:darkblue;font-size:16px;"><i class="fa fa-th"></i> <b>HYPER POSITIONS</b></span>';
$_['header_title']		= 'HYPER POSITIONS';
$_['head_title']		= '<span style="color:darkblue;"><i class="fa fa-th"></i> <b>HYPER POSITIONS</b></span>';
$_['heading_text_title']   = 'Расширения';
// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки модуля';
// Entry
$_['entry_status']     = 'Статус';
// Help
$_['help_name']     = '';
$_['help_name_title']     = '';
$_['help_name_titles']     = '';
$_['help_list']     = '';
$_['help_text']     = '';
$_['help_warning']     = '';
$_['help_ok']     = '';
$_['help_end']     = '';
// Help Users
$_['help_name']     = '';
$_['help_first']     = '';
$_['help_second']     = '';
$_['info_first']     = '';
$_['info_second']     = '';
$_['info_third']     = '';
$_['info_fourth']     = '';
// Error
$_['error_permission'] = 'У Вас нет прав для изменения модуля Аккаунт!';

