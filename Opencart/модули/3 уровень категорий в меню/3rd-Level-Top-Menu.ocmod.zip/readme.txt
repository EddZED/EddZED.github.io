OpenCart 3.0.X 3rd Level Top Menu

What this module provides:
1. View 3 category levels (or sub-sub-category) in the top menu for the standard template on desktop view as well as smartphone /tablet view.
2. No special javascript stylesheet additions, so it is easy to modify your stylesheet in yur child theme.

What this module does not provide:
1. Cannot display 4th level category.
2. Does not display 3rd level in the side category menu - that requires a different modification.



Installation

1. Log into your admin area, go to Extensions / Installer and upload the 3rd-Level-Top-Menu.ocmod.zip file.

2. Go to Extensions / Modifications. You should see this 3rd Level Menu tool. 

3. Click on the refresh button on the top right of the page.



