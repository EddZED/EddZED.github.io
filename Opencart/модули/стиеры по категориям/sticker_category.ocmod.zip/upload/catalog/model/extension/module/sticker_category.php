<?php
class ModelExtensionModuleStickerCategory extends Model {
	public function getStickerCategory($category) {
		$language_id = $this->config->get('config_language_id');
		$sticker_data = array();
					
		if ($category['sticker_category_custom'] && $this->config->get('module_sticker_category_custom')) {
			$sticker_category_custom = unserialize($category['sticker_category_custom']);
				
			foreach ($this->config->get('module_sticker_category_custom') as $key => $value) {
				if ($value['status'] && isset($sticker_category_custom[$key]['status']) && $sticker_category_custom[$key]['status'] && (!$value['date_start'] || $value['date_start'] <= date('Y-m-d')) && (!$value['date_end'] || $value['date_end'] > date('Y-m-d'))) {
					$sticker_data[] = array(
						'class' 	 => 'sticker-category-custom' . $key,
						'name'  	 => $value[$language_id]['name'],
						'image' 	 => $value['image'] ? 'style="background: url(\'/image/' . $value['image'] . '\');"' : '',
						'sort_order' => $value['sort_order']
					);
				}
			}
		}
		
		if ($sticker_data) {
			$sort_order = array();
			
			foreach ($sticker_data as $key => $value) {
				$sort_order[$key] = $value['sort_order'];
			}

			array_multisort($sort_order, SORT_ASC, $sticker_data);
			
			return $sticker_data;
		} else {
			return false;
		}
	}
}