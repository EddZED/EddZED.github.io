<?php
class ControllerExtensionModuleStickerCategory extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/sticker_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_sticker_category', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');
			
			if ((int)$this->request->post['module_sticker_category_apply']) {
				$this->response->redirect($this->url->link('extension/module/sticker_category', 'user_token=' . $this->session->data['user_token'], true));
			}

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['sticker_category_custom_name'])) {
			$data['error_sticker_category_custom_name'] = $this->error['sticker_category_custom_name'];
		} else {
			$data['error_sticker_category_custom_name'] = array();
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/sticker_category', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/module/sticker_category', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		
		if (isset($this->request->post['module_sticker_category_status'])) {
			$data['module_sticker_category_status'] = $this->request->post['module_sticker_category_status'];
		} else {
			$data['module_sticker_category_status'] = $this->config->get('module_sticker_category_status');
		}
		
		$this->load->model('tool/image');
		
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 70, 70);
		
		if (isset($this->request->post['module_sticker_category_top'])) {
			$data['module_sticker_category_top'] = $this->request->post['module_sticker_category_top'];
		} else {
			$data['module_sticker_category_top'] = $this->config->get('module_sticker_category_top');
		}
		
		if (isset($this->request->post['module_sticker_category_title'])) {
			$data['module_sticker_category_title'] = $this->request->post['module_sticker_category_title'];
		} else {
			$data['module_sticker_category_title'] = $this->config->get('module_sticker_category_title');
		}
		
		if (isset($this->request->post['module_sticker_category_subcategory_title'])) {
			$data['module_sticker_category_subcategory_title'] = $this->request->post['module_sticker_category_subcategory_title'];
		} else {
			$data['module_sticker_category_subcategory_title'] = $this->config->get('module_sticker_category_subcategory_title');
		}
		
		if (isset($this->request->post['module_sticker_category_custom'])) {
			$data['module_sticker_category_custom'] = $this->request->post['module_sticker_category_custom'];
		} elseif ($this->config->get('module_sticker_category_custom')) {
			$data['module_sticker_category_custom'] = $this->config->get('module_sticker_category_custom');
		} else {
			$data['module_sticker_category_custom'] = array();
		}
		
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/sticker_category', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/sticker_category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		$this->load->model('localisation/language');

		$languages = $this->model_localisation_language->getLanguages();
		
		if (isset($this->request->post['module_sticker_category_custom'])) {
			 foreach ($this->request->post['module_sticker_category_custom'] as $key => $sticker) {
			
				foreach ($languages as $language) {
					if ((utf8_strlen($sticker[$language['language_id']]['name']) < 1)) {
						$this->error['sticker_category_custom_name'][$key][$language['language_id']] = $this->language->get('error_name');
						
						$this->error['warning'] = $this->language->get('error_name');
					}
				}
			}
		}

		return !$this->error;
	}
	
	public function install() {
		$this->load->model('extension/module/sticker_category');
		$this->model_extension_module_sticker_category->createColumns();
	}
}