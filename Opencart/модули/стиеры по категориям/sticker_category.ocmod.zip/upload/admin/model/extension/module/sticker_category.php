<?php
class ModelExtensionModuleStickerCategory extends Model {
	public function createColumns () {
		// Custom
		$query = array();
		
		$query = $this->db->query("SHOW COLUMNS FROM " . DB_PREFIX . "category");

		$sticker_category_custom = false;

		if ($query->rows) {
			
			foreach ($query->rows as $row) {
				if ($row['Field'] == 'sticker_category_custom') {
					$sticker_category_custom = true;
				}
			}

			if (!$sticker_category_custom) {
				$this->db->query("ALTER TABLE `" . DB_PREFIX . "category`  ADD `sticker_category_custom` TEXT NOT NULL;");
			}
		}
	}
}