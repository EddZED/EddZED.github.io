<?php
// Text
$_['tab_sticker'] = "Stickers";