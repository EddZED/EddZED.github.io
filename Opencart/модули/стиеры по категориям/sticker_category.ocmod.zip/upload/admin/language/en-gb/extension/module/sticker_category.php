<?php
// Heading
$_['heading_title'] 	    	= 'Category Sticker';

// Text
$_['text_extension']   			= 'Extensions';
$_['text_success']     			= 'Success: You have modified module!';
$_['text_edit']        			= 'Edit module';
$_['text_date_added']     		= 'Date added';
$_['text_date_available']     	= 'Date available';
$_['text_sticker_custom']      	= 'Custom Stickers';

// Entry
$_['entry_status'] 				= 'Status';
$_['entry_name'] 				= 'Name';
$_['entry_image'] 				= 'Image';
$_['entry_sort_order']       	= 'Sort Order';
$_['entry_top']       			= 'Top menu';
$_['entry_category_title']      = 'Category title';
$_['entry_subcategory_title']   = 'Subcategory title';
$_['entry_date']   				= 'Date';
$_['entry_date_start']   		= 'Date start';
$_['entry_date_end']   			= 'Date end';

// Button
$_['button_apply']   			= 'Apply';

// Help
$_['help_top']               	= 'Display in the top menu bar. Only works for the top parent categories.';
$_['help_category_title']       = 'Display in the category title (category page).';
$_['help_subcategory_title']    = 'Display in the subcategory title (category page).';

// Error
$_['error_permission'] 			= 'Warning: You do not have permission to modify module!';	
$_['error_name']      			= 'Name required!';