<?php 
// Heading
$_['heading_title'] 	    	= 'Стикеры для категорий';

// Text
$_['text_extension']   			= 'Расширения';
$_['text_success']     			= 'Настройки успешно изменены!';
$_['text_edit']        			= 'Настройки модуля';
$_['text_sticker_custom']      	= 'Пользовательские стикеры';
$_['text_date_added']     		= 'Дата добавления';
$_['text_date_available']     	= 'Дата поступления';

// Entry
$_['entry_status'] 				= 'Статус';
$_['entry_name'] 				= 'Название';
$_['entry_image'] 				= 'Изображение';
$_['entry_sort_order']       	= 'Порядок сортировки';
$_['entry_top']       			= 'Главное меню';
$_['entry_category_title']      = 'Заголовок категории';
$_['entry_subcategory_title']   = 'Заголовок подкатегории';
$_['entry_date']   				= 'Дата';
$_['entry_date_start']   		= 'Дата начала';
$_['entry_date_end']   			= 'Дата окончания';

// Button
$_['button_apply']   			= 'Применить';

// Help
$_['help_top']       			= 'Показывать в главном меню (только для главных родительских категорий).';
$_['help_category_title']       = 'Показывать возле заголовка категории (на странице категории).';
$_['help_subcategory_title']    = 'Показывать возле заголовка подкатегории (на странице категории).';

// Error
$_['error_permission'] 			= 'У вас нет прав для управления данным модулем!';
$_['error_name']     			= 'Введите название стикера!';