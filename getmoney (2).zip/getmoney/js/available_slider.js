 $('.slider-desctop').slick({
    fade: true,
    appendArrows: ".arrows-desctop",
    prevArrow: '<button type = "button" class = "slick-prev"><svg width="11" height="8" viewBox="0 0 11 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.7137 4.21415H1.28516M1.28516 4.21415L4.71373 0.571289M1.28516 4.21415L4.71373 7.64272" stroke="#DCDCDC"/></svg></button>',
    nextArrow: '<button type = "button" class = "slick-next"><svg width="11" height="8" viewBox="0 0 11 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.286272 4.21439H9.71484M9.71484 4.21439L6.28627 0.571533M9.71484 4.21439L6.28627 7.64296" stroke="#DCDCDC"/></svg></button>'
 });
 $('.slider-mobile').slick({
    fade: true,
    appendArrows: ".arrows-mobile",
    prevArrow: '<button type = "button" class = "slick-prev"><svg width="11" height="8" viewBox="0 0 11 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.7137 4.21415H1.28516M1.28516 4.21415L4.71373 0.571289M1.28516 4.21415L4.71373 7.64272" stroke="#DCDCDC"/></svg></button>',
    nextArrow: '<button type = "button" class = "slick-next"><svg width="11" height="8" viewBox="0 0 11 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.286272 4.21439H9.71484M9.71484 4.21439L6.28627 0.571533M9.71484 4.21439L6.28627 7.64296" stroke="#DCDCDC"/></svg></button>'
 });